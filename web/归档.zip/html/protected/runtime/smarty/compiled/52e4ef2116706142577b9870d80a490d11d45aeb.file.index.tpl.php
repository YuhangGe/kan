<?php /* Smarty version Smarty-3.1.13, created on 2013-06-01 00:09:49
         compiled from "/Users/abraham/workspace/kankan/web/html/protected/modules/admin/views/default/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16686546651a8cb4d381f65-50246201%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '52e4ef2116706142577b9870d80a490d11d45aeb' => 
    array (
      0 => '/Users/abraham/workspace/kankan/web/html/protected/modules/admin/views/default/index.tpl',
      1 => 1370016136,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16686546651a8cb4d381f65-50246201',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'this' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_51a8cb4d3b4344_90330173',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51a8cb4d3b4344_90330173')) {function content_51a8cb4d3b4344_90330173($_smarty_tpl) {?><h4>活动管理</h4>

<?php echo $_smarty_tpl->tpl_vars['this']->value->widget('bootstrap.widgets.TbTabs',array('type'=>'tabs','placement'=>'left','tabs'=>array(array('label'=>'查看活动','content'=>'<p>I\'m in Section 1.</p>','active'=>true),array('label'=>'Section 2','content'=>'<p>Howdy, I\'m in Section 2.</p>'),array('label'=>'搜索活动','content'=>'<p>What up girl, this is Section 3.</p>'))),true);?>
<?php }} ?>