<?php /* Smarty version Smarty-3.1.13, created on 2013-06-01 00:09:33
         compiled from "/Users/abraham/workspace/kankan/web/html/protected/modules/admin/views/vedio/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:75543507751a8cb3de13ba6-22357148%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '17d3aed8c850a6c98e61cf7abe0a5918ba6f197d' => 
    array (
      0 => '/Users/abraham/workspace/kankan/web/html/protected/modules/admin/views/vedio/index.tpl',
      1 => 1370011044,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '75543507751a8cb3de13ba6-22357148',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_51a8cb3de14333_34585843',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51a8cb3de14333_34585843')) {function content_51a8cb3de14333_34585843($_smarty_tpl) {?><?php }} ?>