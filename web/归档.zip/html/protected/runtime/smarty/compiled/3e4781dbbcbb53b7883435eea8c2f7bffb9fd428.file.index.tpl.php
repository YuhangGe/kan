<?php /* Smarty version Smarty-3.1.13, created on 2013-06-19 01:06:10
         compiled from "/Users/abraham/workspace/kan/web/html/protected/modules/admin/views/photo/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:118246367951c09382c05105-29922760%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3e4781dbbcbb53b7883435eea8c2f7bffb9fd428' => 
    array (
      0 => '/Users/abraham/workspace/kan/web/html/protected/modules/admin/views/photo/index.tpl',
      1 => 1371490730,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '118246367951c09382c05105-29922760',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_51c09382c2ab36_68808841',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51c09382c2ab36_68808841')) {function content_51c09382c2ab36_68808841($_smarty_tpl) {?><div class="row-fluid sortable">
    <div class="box span12">
        <div class="box-header well" data-original-title>
            <h2><i class="icon-picture"></i> 所有图片</h2>
            <div class="box-icon">
                
                
                
            </div>
        </div>
        <div class="box-content">

            <ul class="thumbnails gallery">

                
                    
                

            </ul>
            <div class="page-info" style="padding-left: 18px;">
                <p>第0页，共0页</p>
            </div>
            <div class="dataTables_paginate paging_bootstrap pagination" style="text-align: center;">
                <ul>
                    <li class="prev disabled"><a href="javascript:loadPrevPage();">← 上一页</a></li>
                    <li class="next disabled"><a href="javascript:loadNextPage();">下一页 → </a></li>
                </ul>
            </div>
        </div>
    </div><!--/span-->

</div><!--/row-->


<script type="text/javascript">
    CUR_PAGE = 0;
    MAX_PAGE = 1;
    function loadPage(idx) {
        $.post("/admin/photo/page", {
            'page_index' : idx
        }, function(rtn) {
            if(!rtn.success) {
                alert("网络错误！请重试。");
                return;
            }
            var _d = rtn.data;
            CUR_PAGE = _d.page_index;
            MAX_PAGE = _d.total_page;
            var _u = $(".gallery").html("");
            for(var i=0;i<_d.photo_list.length;i++) {
                var p = _d.photo_list[i];
                $("<li class='thumbnail'></li>").append(
                    $("<a class='kan-photo' href='"+ p.image_url +"' title='所属用户："+ p.user_name+"，所属活动："+ p.act_name+"'></a>").append($("<img src='"+p.thumb_url+"'/>"))
                ).append(
                    "<p>所属用户：<a href='/admin/user/detail#"+ p.user_id+"'>"+ p.user_name+"</a></p>"
                   +"<p>所属活动：<a href='/admin/default/detail#"+ p.act_id+"'>"+ p.act_name+"</a></p>"
                   +'<p onclick="delPhoto('+ p.photo_id+');" class="gallery-delete btn hide"><i class="icon icon-red icon-close"></i></p>'
                        ).appendTo(_u);
            }
            $(".page-info").text("第"+(CUR_PAGE+1)+"页，共"+(MAX_PAGE+1)+"页");
            $.colorbox.remove();
            $('.kan-photo').colorbox({rel:'thumbnail .kan-photo', transition:"elastic", maxWidth:"95%", maxHeight:"95%"});

            if(CUR_PAGE === MAX_PAGE) {
                $(".pagination .next").addClass("disabled");
            } else {
                $(".pagination .next").removeClass("disabled");
            }
            if(CUR_PAGE === 0) {
                $(".pagination .prev").addClass("disabled");
            } else {
                $(".pagination .prev").removeClass("disabled");
            }
        }, 'json');
    }
    function viewReady() {
        loadPage(0);
    }
    function loadNextPage() {
        if(CUR_PAGE<MAX_PAGE) {
            loadPage(CUR_PAGE+1);
        }
    }
    function loadPrevPage() {
        if(CUR_PAGE>0) {
            loadPage(CUR_PAGE-1);
        }
    }
</script>
<?php }} ?>