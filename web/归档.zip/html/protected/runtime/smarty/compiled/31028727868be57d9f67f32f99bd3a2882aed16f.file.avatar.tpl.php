<?php /* Smarty version Smarty-3.1.13, created on 2013-06-06 20:33:27
         compiled from "/Users/abraham/workspace/kan/web/html/protected/views/test/avatar.tpl" */ ?>
<?php /*%%SmartyHeaderCode:149306186551b081972a02c4-01530907%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '31028727868be57d9f67f32f99bd3a2882aed16f' => 
    array (
      0 => '/Users/abraham/workspace/kan/web/html/protected/views/test/avatar.tpl',
      1 => 1370522003,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '149306186551b081972a02c4-01530907',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'Yii' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_51b081972c77c4_32592227',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51b081972c77c4_32592227')) {function content_51b081972c77c4_32592227($_smarty_tpl) {?><!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="http://jcrop-cdn.tapmodo.com/v0.9.12/css/jquery.Jcrop.css" rel="text/css"/>
    <script type="text/javascript" src="/js/jquery-2.0.0.min.js"></script>
    <script type="text/javascript" src="http://jcrop-cdn.tapmodo.com/v0.9.12/js/jquery.Jcrop.js"></script>
    <script type="text/javascript">
        $.log = function(msg) {
            console.log(msg);
        }
    </script>
    <title><?php echo $_smarty_tpl->tpl_vars['Yii']->value->name;?>
</title>
</head>

<body>


    <script type="text/javascript">

        function open() {
//            $.log($("#file")[0].files);
//            return;
            var fs = $("#file")[0].files;
            if(fs.length===0) {
                return;
            }
            var reader = new FileReader();
            reader.onload = function(e){
                var i = $("#jcrop_target");
                i[0].src = this.result;
                i[0].onload = function() {
                    jcrop.destroy();
                    i.css({
                        'width' : "",
                        'height' : ""
                    })
                    do_jcrop();
                };
            }
            reader.readAsDataURL(fs[0]);
        }

        function showPreview(c)
        {
            if (parseInt(c.w) > 0)
            {
                c.x /= bili;
                c.y /= bili;
                c.w /= bili;
                ctx.drawImage(img, Math.round(c.x), Math.round(c.y), Math.round(c.w), Math.round(c.w), 0, 0, H, H);
            }
        }

        function onSelect(c) {
            showPreview(c);
            var ni =  new Image();
            ni.src = cvs.toDataURL("image/png");
//            $.log(cvs.toDataURL());
        }
        var H = 150;

        var cvs, ctx, img, jcrop, bili;

        function do_jcrop() {
            bili = img.height / img.naturalHeight;
            $.log(bili);
            $('#jcrop_target').Jcrop({
                onChange: showPreview,
                onSelect: onSelect,
                aspectRatio: 1
            }, function() {
                jcrop = this;
            });
        }
        $(function(){

            $("#file").change(open);

            img = $("#jcrop_target")[0];
            cvs = $('#preview')[0];
            ctx = cvs.getContext("2d");
            cvs.width = H;
            cvs.height = H;

            do_jcrop();

        });

    </script>


<div>
    <table cellspacing="0" cellpadding="0" border="0">
        <tbody>
            <tr>
                <td>
                    <img style="max-height: 400px" src="http://jcrop-cdn.tapmodo.com/v0.9.10/demos/demo_files/pool.jpg" id="jcrop_target" />
                </td>
                <td>
                    <div style="width:150px;height:150px;overflow:hidden;margin-left:5px;">
                        <canvas id="preview"></canvas>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>
<div>
    <input type="file" id="file"/><br/>
    <input type="button" onclick="submit();" value="Upload">
</div>
<div id="output">

</div>

</body>
</html>
<?php }} ?>