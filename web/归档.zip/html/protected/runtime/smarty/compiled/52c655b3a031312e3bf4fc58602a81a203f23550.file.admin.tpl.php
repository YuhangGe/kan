<?php /* Smarty version Smarty-3.1.13, created on 2013-06-11 17:16:52
         compiled from "/Users/abraham/workspace/kan/web/html/themes/bootstrap/views/layouts/admin.tpl" */ ?>
<?php /*%%SmartyHeaderCode:199241635151b6eb04249386-40252277%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '52c655b3a031312e3bf4fc58602a81a203f23550' => 
    array (
      0 => '/Users/abraham/workspace/kan/web/html/themes/bootstrap/views/layouts/admin.tpl',
      1 => 1370015803,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '199241635151b6eb04249386-40252277',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'Yii' => 0,
    'this' => 0,
    'cur_url' => 0,
    'content' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_51b6eb04293bb3_99002888',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51b6eb04293bb3_99002888')) {function content_51b6eb04293bb3_99002888($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include '/Users/abraham/workspace/kan/web/html/protected/vendors/Smarty/plugins/modifier.date_format.php';
?><!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>KanKan Admin</title>

	<?php echo $_smarty_tpl->tpl_vars['Yii']->value->bootstrap->register();?>


    <link rel="stylesheet" type="text/css" href="/css/admin_styles.css" />

</head>

<body>


<?php $_smarty_tpl->tpl_vars["cur_url"] = new Smarty_variable(((string)$_smarty_tpl->tpl_vars['this']->value->uniqueid)."/".((string)$_smarty_tpl->tpl_vars['this']->value->action->Id), null, 0);?>

<?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['cur_url']->value=='admin/default/index';?>
<?php $_tmp1=ob_get_clean();?><?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['cur_url']->value=='admin/user/index';?>
<?php $_tmp2=ob_get_clean();?><?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['cur_url']->value=='admin/image/index';?>
<?php $_tmp3=ob_get_clean();?><?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['cur_url']->value=='admin/vedio/index';?>
<?php $_tmp4=ob_get_clean();?><?php ob_start();?><?php echo !$_smarty_tpl->tpl_vars['Yii']->value->user->isAdmin();?>
<?php $_tmp5=ob_get_clean();?><?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['cur_url']->value=='admin/default/login';?>
<?php $_tmp6=ob_get_clean();?><?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['Yii']->value->user->isAdmin();?>
<?php $_tmp7=ob_get_clean();?><?php echo $_smarty_tpl->tpl_vars['this']->value->widget('bootstrap.widgets.TbNavbar',array('type'=>'inverse','brand'=>'看看后台管理','brandUrl'=>'#','items'=>array(array('class'=>'bootstrap.widgets.TbMenu','items'=>array(array('label'=>'活动','url'=>array('/admin/default/index'),'active'=>$_tmp1),array('label'=>'用户','url'=>array('/admin/user'),'active'=>$_tmp2),array('label'=>'照片','url'=>array('/admin/image'),'active'=>$_tmp3),array('label'=>'视频','url'=>array('/admin/vedio'),'active'=>$_tmp4),array('label'=>'登陆','url'=>array('/admin/default/login'),'visible'=>$_tmp5,'active'=>$_tmp6),array('label'=>"登出",'url'=>array('/admin/default/logout'),'visible'=>$_tmp7))))),true);?>

<div class="container" id="page">


    <div id="content">
        <?php echo $_smarty_tpl->tpl_vars['content']->value;?>


    </div>

	<div class="clear"></div>

</div><!-- page -->

<div id="footer">
    版权所有 &copy;<?php echo smarty_modifier_date_format(time(),'%Y');?>
 南京快播动漫
</div><!-- footer -->

</body>
</html>
<?php }} ?>