<?php /* Smarty version Smarty-3.1.13, created on 2013-06-01 00:09:48
         compiled from "/Users/abraham/workspace/kankan/web/html/protected/modules/admin/views/user/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:176999649551a8cb4c624cb1-75308926%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '356a9c0d8e45d10a20eba56ce70f455ab265a4f2' => 
    array (
      0 => '/Users/abraham/workspace/kankan/web/html/protected/modules/admin/views/user/index.tpl',
      1 => 1370010826,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '176999649551a8cb4c624cb1-75308926',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_51a8cb4c625367_92094223',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51a8cb4c625367_92094223')) {function content_51a8cb4c625367_92094223($_smarty_tpl) {?><?php }} ?>