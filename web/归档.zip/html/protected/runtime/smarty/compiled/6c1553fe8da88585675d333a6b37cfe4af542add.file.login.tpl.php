<?php /* Smarty version Smarty-3.1.13, created on 2013-06-11 17:16:52
         compiled from "/Users/abraham/workspace/kan/web/html/protected/modules/admin/views/default/login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:158319678251b6eb041e7f57-03216410%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6c1553fe8da88585675d333a6b37cfe4af542add' => 
    array (
      0 => '/Users/abraham/workspace/kan/web/html/protected/modules/admin/views/default/login.tpl',
      1 => 1369990279,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '158319678251b6eb041e7f57-03216410',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'this' => 0,
    'model' => 0,
    'form' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_51b6eb0422a605_72600445',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51b6eb0422a605_72600445')) {function content_51b6eb0422a605_72600445($_smarty_tpl) {?>
<h4>登陆后台</h4>
<?php $_smarty_tpl->tpl_vars["form"] = new Smarty_variable($_smarty_tpl->tpl_vars['this']->value->beginWidget('bootstrap.widgets.TbActiveForm',array('id'=>'verticalForm','htmlOptions'=>array('class'=>'well'))), null, 0);?>

<?php echo $_smarty_tpl->tpl_vars['form']->value->textFieldRow($_smarty_tpl->tpl_vars['model']->value,'username',array('class'=>'span3'));?>

<?php echo $_smarty_tpl->tpl_vars['form']->value->passwordFieldRow($_smarty_tpl->tpl_vars['model']->value,'password',array('class'=>'span3'));?>

<br/>
<?php echo $_smarty_tpl->tpl_vars['this']->value->widget('bootstrap.widgets.TbButton',array('buttonType'=>'submit','label'=>'登陆'),true);?>


<?php $_smarty_tpl->tpl_vars["form_end"] = new Smarty_variable($_smarty_tpl->tpl_vars['this']->value->endWidget(), null, 0);?><?php }} ?>