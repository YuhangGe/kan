<?php /* Smarty version Smarty-3.1.13, created on 2013-06-19 01:06:29
         compiled from "/Users/abraham/workspace/kan/web/html/protected/modules/admin/views/video/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:124371428451c0939509e156-19388723%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5a351ce625f5ae4ea28fc58ca9c43d51e909601c' => 
    array (
      0 => '/Users/abraham/workspace/kan/web/html/protected/modules/admin/views/video/index.tpl',
      1 => 1371573580,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '124371428451c0939509e156-19388723',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_51c093950c10a5_70397838',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51c093950c10a5_70397838')) {function content_51c093950c10a5_70397838($_smarty_tpl) {?><div class="row-fluid sortable">
    <div class="box span12">
        <div class="box-header well" data-original-title>
            <h2><i class="icon-user"></i> 视频</h2>
            <div class="box-icon">
                
                
                
            </div>
        </div>
        <div class="box-content">

            <table aoDataSource="/admin/table/video" aoColumns="video" fnDrawCallback="video" class="table table-video table-striped table-bordered bootstrap-datatable datatable">
                <thead>
                <tr>
                    <td>ID</td>
                    <th>节目名称</th>
                    <th>所属星客</th>
                    <th>所属活动</th>
                    <th>上传时间</th>
                    <th>视频海报</th>
                    <th>操作</th>
                </tr>
                </thead>
                <tbody>
                </tbody>

            </table>
        </div>
    </div><!--/span-->

</div><!--/row-->


<div id="table-edit-row-template" style="display: none">
    <a class="btn btn-success" href="/admin/video/detail#VIDEO_ID">
        <i class="icon-zoom-in icon-white"></i>
        查看视频
    </a>
    <a class="btn btn-info" href="javascript:uploadPoster('VIDEO_ID');">
        <i class="icon-edit icon-white"></i>
        上传海报
    </a>
    <a class="btn btn-danger" href="javascript:delVideo('VIDEO_ID');">
        <i class="icon-trash icon-white"></i>
        删除
    </a>
</div>

<div class="modal hide fade" id="posterDialog">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">×</button>
        <h3>上传海报</h3>
    </div>
    <div class="modal-body">
        <div class="alert alert-info" id="poster-process" style="position: relative; top: 5px;">为视频上传海报</div>

        <div class="control-group" id="act-detail">
            <label class="control-label" for="fileImage">上传海报</label>
            <div class="controls">
                <input class="input-file uniform_on" id="fileImage" type="file">
            </div>
        </div>
    </div>
    <div class="modal-footer">
        <a href="#" class="btn" data-dismiss="modal">取消</a>
        
    </div>
</div>



    <script type="text/javascript">

        CUR_VIDEO = 0;

        function viewStart() {
            window.fnDrawCallback = {
                'video' : function() {
                    $.colorbox.remove();
                    $(".poster_image").colorbox({transition:"elastic", maxWidth:"95%", maxHeight:"95%"});
                }
            };
                        window.aoColumns = {'video' : [
                            { "mData": "video_id"},
                            { "mData": "video_name" },
                            { "mData": "user_name", "mRender" : function(data, type, ooData) {
                                return "<a href='/admin/user/detail#"+ooData['user_id']+"'>"+data+"</a>";
                            }
                            },
                            { "mData": "act_name", "mRender" : function(data, type, ooData) {
                                return "<a href='/admin/default/detail#"+ooData['act_id']+"'>"+data+"</a>";
                            }
                            },
                            { "mData": "upload_time","mRender": function(data) {
                                return $.datepicker.formatDate("yy年mm月dd日", new Date(Number(data)*1000));
                            }
                            },
                            { "mData": "poster_url","mRender": function(data) {
                                if(data===null || data.trim() === "") {
                                    return "未上传";
                                } else {
                                    return "<a class='poster_image' href='"+data+"'>查看图片</a>";
                                }
                            }
                            },
                            {
                                "mData" : "video_id",
                                "mRender" : function(data) {
                                    return  document.getElementById("table-edit-row-template").innerHTML.replace(/VIDEO_ID/g, data);
                                }
                            }
                        ]};

        }


        function delVideo(id) {
            if(confirm("确认删除视频？", "删除")) {
                $.log("del:"+id);
            }
        }

        function viewReady() {
            $("#fileImage").change(uploadImage);
        }
        function uploadPoster(video_id) {
            CUR_VIDEO = video_id;
            $("#posterDialog").modal("show");
        }
        function uploadImage() {
            var fs = $("#fileImage")[0].files;
            if(fs.length===0) {
                return;
            }
            $("#poster-process").show().text("正在上传(0%)...");
            var img = fs[0];
            var fd = new FormData();
            fd.append("image_file", img);
            fd.append("video", CUR_VIDEO);

            $.ajax({
                url: "/admin/video/poster",
                data: fd,
                dataType : "json",
                //Options to tell JQuery not to process data or worry about content-type
                cache: false,
                contentType: false,
                processData: false,
                type: 'POST',

                xhr: function() {  // custom xhr
                    var myXhr = $.ajaxSettings.xhr();
                    if(myXhr.upload){ // check if upload property exists
                        myXhr.upload.addEventListener('progress', uploadProcess, false); // for handling the progress of the upload
                    }
                    return myXhr;
                },
                success : showImage
            });
        }

        function uploadProcess(e) {
            if(e.lengthComputable){
                $("#poster-process").text("正在上传("+Math.round(e.loaded/ e.total * 100)+"%)...");
            }
        }

        function showImage(rtn) {
            if(!rtn.success) {
                alert('网络错误，请重试。');
                return;
            }
            $("#posterDialog").modal("hide");
            $(".table-video").DataTable().fnDraw();

        }

    </script>




<?php }} ?>