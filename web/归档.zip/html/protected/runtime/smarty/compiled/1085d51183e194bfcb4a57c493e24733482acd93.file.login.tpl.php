<?php /* Smarty version Smarty-3.1.13, created on 2013-06-01 00:09:45
         compiled from "/Users/abraham/workspace/kankan/web/html/protected/modules/admin/views/default/login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:32725640851a8cb49728002-74075891%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1085d51183e194bfcb4a57c493e24733482acd93' => 
    array (
      0 => '/Users/abraham/workspace/kankan/web/html/protected/modules/admin/views/default/login.tpl',
      1 => 1369990279,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '32725640851a8cb49728002-74075891',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'this' => 0,
    'model' => 0,
    'form' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_51a8cb4976ab69_94431788',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51a8cb4976ab69_94431788')) {function content_51a8cb4976ab69_94431788($_smarty_tpl) {?>
<h4>登陆后台</h4>
<?php $_smarty_tpl->tpl_vars["form"] = new Smarty_variable($_smarty_tpl->tpl_vars['this']->value->beginWidget('bootstrap.widgets.TbActiveForm',array('id'=>'verticalForm','htmlOptions'=>array('class'=>'well'))), null, 0);?>

<?php echo $_smarty_tpl->tpl_vars['form']->value->textFieldRow($_smarty_tpl->tpl_vars['model']->value,'username',array('class'=>'span3'));?>

<?php echo $_smarty_tpl->tpl_vars['form']->value->passwordFieldRow($_smarty_tpl->tpl_vars['model']->value,'password',array('class'=>'span3'));?>

<br/>
<?php echo $_smarty_tpl->tpl_vars['this']->value->widget('bootstrap.widgets.TbButton',array('buttonType'=>'submit','label'=>'登陆'),true);?>


<?php $_smarty_tpl->tpl_vars["form_end"] = new Smarty_variable($_smarty_tpl->tpl_vars['this']->value->endWidget(), null, 0);?><?php }} ?>