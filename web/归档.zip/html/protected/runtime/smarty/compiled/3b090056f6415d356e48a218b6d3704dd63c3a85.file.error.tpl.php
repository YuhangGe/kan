<?php /* Smarty version Smarty-3.1.13, created on 2013-05-27 14:17:11
         compiled from "/Users/abraham/workspace/kankan/web/html/protected/views/site/error.tpl" */ ?>
<?php /*%%SmartyHeaderCode:134286581651a2fa6728d321-27936858%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3b090056f6415d356e48a218b6d3704dd63c3a85' => 
    array (
      0 => '/Users/abraham/workspace/kankan/web/html/protected/views/site/error.tpl',
      1 => 1369374587,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '134286581651a2fa6728d321-27936858',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'code' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_51a2fa672b5d50_38330915',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51a2fa672b5d50_38330915')) {function content_51a2fa672b5d50_38330915($_smarty_tpl) {?>
<h2>Error <?php echo $_smarty_tpl->tpl_vars['code']->value;?>
</h2>

<div class="error">
<?php echo $_smarty_tpl->tpl_vars['message']->value;?>

</div><?php }} ?>