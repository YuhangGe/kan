<?php /* Smarty version Smarty-3.1.13, created on 2013-05-31 15:56:20
         compiled from "/Users/abraham/workspace/kankan/web/html/protected/modules/admin/views/site/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:29480724851a857a4720759-76141461%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1f3d32d7edbcbd5cab3fd0801de190781df32d9e' => 
    array (
      0 => '/Users/abraham/workspace/kankan/web/html/protected/modules/admin/views/site/index.tpl',
      1 => 1369984963,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '29480724851a857a4720759-76141461',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_51a857a4721157_15239963',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51a857a4721157_15239963')) {function content_51a857a4721157_15239963($_smarty_tpl) {?><?php }} ?>