<?php
/**
 * User: xiaoge
 * At: 13-5-31 10:36
 * Email: abraham1@163.com
 */


class ImageController extends AController{
    public function actionIndex() {
        $this->render("index");
    }
}