<?php
/**
 * User: xiaoge
 * At: 13-6-8 7:26
 * Email: abraham1@163.com
 */


class TipForm extends CFormModel{
    public $email;
    public $phone;
    public $nick_name;
}